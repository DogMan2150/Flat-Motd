surface.CreateFont("Bebas45", {
	font = "Bebas Neue", 
	size = 45, 
	weight = 500, 
	blursize = 0, 
	scanlines = 0, 
	antialias = true, 
	underline = false, 
	italic = false, 
	strikeout = false, 
	symbol = false, 
	rotary = false, 
	shadow = false, 
	additive = false, 
	outline = false, 
})

net.Receive("FullMOTD_Open", function(len)

	
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0,0)
	frame:SetTitle("")
	frame:RequestFocus()
	frame:MakePopup()
	frame:ShowCloseButton(false)
	frame.Paint = function()
		draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), Color(0,0,0,200))
		draw.RoundedBox(0, 0, 0, ScrW(), 30+10+64+10, FullMOTD.BackgroundColour)
	end
	frame.Think = function()
		gui.EnableScreenClicker(true)
	end
	
	local FullMOTD_HTML_Panel = vgui.Create("HTML", frame)
	FullMOTD_HTML_Panel:SetPos(50, 164+20)
	FullMOTD_HTML_Panel:SetSize(ScrW()-50-50, ScrH()-250)
	FullMOTD_HTML_Panel:OpenURL(FullMOTD.DefaultURL)
	
	local loops = 0
	for k, v in pairs(FullMOTD.ButtonsTable) do
	local FullMOTD_Button_Panel = vgui.Create("DButton", frame)
	FullMOTD_Button_Panel:SetSize(200,10+64+10+50)
	FullMOTD_Button_Panel:SetPos(FullMOTD.StartingPos+loops*FullMOTD.SpaceBetween, 30)
	FullMOTD_Button_Panel:SetText("")
	FullMOTD_Button_Panel.Paint = function()
		draw.RoundedBox(0, 0, 0, 200, 10+64+10, FullMOTD.ButtonsTopColour)
		//draw.RoundedBox(0, 0, 10+64+10, 200, 50, Color(46, 204, 113))
	end
	FullMOTD_Button_Panel.DoClick = function()
		if type(v.func) == "string" then	   
			FullMOTD_HTML_Panel:OpenURL(v.func)
		else
			v.func()
		end
	end
	
	local FullMOTD_Button = vgui.Create("DButton", frame)
	FullMOTD_Button:SetSize(FullMOTD.ButtonWidth,FullMOTD.ButtonHeight)
	FullMOTD_Button:SetPos(FullMOTD.StartingPos+loops*FullMOTD.SpaceBetween,10+64+10+30)
	FullMOTD_Button:SetText(k)
	FullMOTD_Button:SetFont("Bebas45")
	FullMOTD_Button:SetColor(FullMOTD.FontColor)
	FullMOTD_Button.Paint = function()
		draw.RoundedBox(0, 0, 0, 200, 50, v.colour)
	end	
	FullMOTD_Button.DoClick = function()
		if type(v.func) == "string" then	   
			FullMOTD_HTML_Panel:OpenURL(v.func)
		else
			v.func()
		end
	end
	
	local FullMOTD_Image = vgui.Create("DImage", FullMOTD_Button_Panel)
	FullMOTD_Image:SetImage(v.icon)
	FullMOTD_Image:SetImageColor(v.icon_colour)
	FullMOTD_Image:SetSize(64, 64)
	FullMOTD_Image:SetPos(100-32, 10)
	
	loops = loops + 1
	end
	
	function FullMOTD:CloseMenu()
		frame:Remove()
		gui.EnableScreenClicker(false)
	end	
	
end)