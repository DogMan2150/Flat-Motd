//Colouring
FullMOTD.BackgroundColour = Color(108, 122, 137) -- What colour should the panel behind the buttons be?
FullMOTD.ButtonsTopColour = Color(242, 241, 239) -- What colour should the top half of the buttons be? (The not separately coloured bits)
FullMOTD.FontColor = Color(255, 255, 255) -- What colour should the text on the buttons be?

//Buttons
FullMOTD.ButtonWidth = 200
FullMOTD.ButtonHeight = 50

//HTML stuff
FullMOTD.DefaultURL = "http://www.garrysmod.com/" -- What url should appear by default?

//Sizing and positioning
FullMOTD.StartingPos = 125 -- How many pixels to the right should there be before buttons start being placed?
FullMOTD.SpaceBetween = 210 -- How much space between each button? (Needs to take into consideration the width of the actual button)


AddFlatMOTDButton("Rules", 
{
	func = "http://www.garrysmod.com/", -- Add something not in quotes to run it as a function
	colour = Color(46, 204, 113), -- What colour should the panel behind the button text be?
	icon_colour = Color(49, 49, 49), -- What colour should the icon be? Just leave as Color(255, 255, 255) for none
	icon = "materials/niandralades/motd/64/64_rules.png" -- Icon file path
})

AddFlatMOTDButton("Website", 
{
	func = "http://www.facepunch.com", 
	colour = Color(25, 181, 254),
	icon_colour = Color(49, 49, 49),
	icon = "materials/niandralades/motd/64/64_web.png"
})

AddFlatMOTDButton("Donate", 
{
	func = "http://www.paypal.co.uk", 
	colour = Color(239, 72, 54),
	icon_colour = Color(49, 49, 49),
	icon = "materials/niandralades/motd/64/64_donate.png"
})

AddFlatMOTDButton("Group", 
{
	func = "http://steamcommunity.com/", 
	colour = Color(249, 191, 59),
	icon_colour = Color(49, 49, 49),
	icon = "materials/niandralades/motd/64/64_users.png"
})

AddFlatMOTDButton("Close", 
{
	func = function()
			FullMOTD:CloseMenu()
		   end, 
	colour = Color(191, 85, 236),
	icon_colour = Color(49, 49, 49),
	icon = "materials/niandralades/motd/64/64_cancel.png",
})
