FullMOTD.ButtonsTable = {}
//local random_colour = 76561198004684789
function AddFlatMOTDButton(name, options)
	
	if not name then 
		name = "Button"
    end
	
	if not options.func then
		error("Command has not been set! Clicking this button doesn't do anything.")
    end
	
	if not options.colour then
		colour = Color(46, 204, 113)
	end
	
	if not options.icon_colour then
		icon_colour = Color(0, 0, 0)
	end
	
	if not options.icon then
		icon = ""
	end
	
	FullMOTD.ButtonsTable[name] = {
		func = options.func, 
		colour = options.colour, 
		icon_colour = options.icon_colour, 
		icon = options.icon
	} 
		
end

