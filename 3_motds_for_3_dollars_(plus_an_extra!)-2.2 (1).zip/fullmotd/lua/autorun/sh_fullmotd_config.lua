FullMOTD = FullMOTD or {}

//Server stuff - See client/cl_fullmotd_config.lua for design stuff!
FullMOTD.ChatCommand = "!motd" -- What command should players enter in chat to re-access the MOTD?
FullMOTD.ConsoleCommand = "fullmotd" -- What command should players enter in console to re-access the MOTD?
FullMOTD.WhitelistedGroups = { "superadmin", "owner", "admin" } -- What groups should NOT see the MOTD when they enter the server?
FullMOTD.ShowOnSpawn = true -- Should the menu appear when you first initially spawn?
FullMOTD.UseFastDL = true -- Change to false to download from Workshop instead

if SERVER then
	
	if FullMOTD.UseFastDL then

	resource.AddFile("materials/niandralades/motd/64/64_rules.png")
	resource.AddFile("materials/niandralades/motd/64/64_web.png")
	resource.AddFile("materials/niandralades/motd/64/64_donate.png")
	resource.AddFile("materials/niandralades/motd/64/64_users.png")
	resource.AddFile("materials/niandralades/motd/64/64_cancel.png")
	
	resource.AddFile("resource/fonts/bebasneue.ttf")
	
	else
		resource.AddWorkshop("529645523")
	end	
end