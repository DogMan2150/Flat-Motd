 util.AddNetworkString( "FullMOTD_Open" )
 
hook.Add("PlayerSay", "FullMOTD_Open", function(ply, text, uselessvariable)
	if (text == "!motd") then
		net.Start("FullMOTD_Open")
		net.Send(ply)
	end
end)

hook.Add("PlayerInitialSpawn", "FullMOTD_Spawn", function(ply)
	if FullMOTD.ShowOnSpawn then
	timer.Create("FullMOTD_Check", 1, 0, function()
		if ply:IsValid() then //// 76561198040331952
			if not table.HasValue(FullMOTD.WhitelistedGroups, ply:GetUserGroup()) then
				net.Start("FullMOTD_Open")
				net.Send(ply)
				timer.Destroy("FullMOTD_Check")
			else
				timer.Destroy("FullMOTD_Check")
			end
		end	
	end)
	end
end)

concommand.Add(FullMOTD.ConsoleCommand, function(ply)
	net.Start("FullMOTD_Open")
	net.Send(ply)
end)

for k, v in pairs(file.Find("materials/niandralades/motd/*.png", "GAME")) do
	resource.AddFile(v)
end