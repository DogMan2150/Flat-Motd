//Don't touch this!]
MetroMOTD = MetroMOTD or {}

//Serverside stuff
MetroMOTD.ChatCommand = "!motd" -- What command should players enter in chat to re-access the MOTD?
MetroMOTD.ConsoleCommand = "metromotd" -- What command should players enter in console to re-access the MOTD?
MetroMOTD.WhitelistedGroups = { "superadmin", "owner", "admin" } -- What groups should NOT see the MOTD when they enter the server?
MetroMOTD.ShowOnSpawn = true -- Should the menu appear when you first initially spawn?
MetroMOTD.UseFastDL = true -- Change to false to download from Workshop instead

MetroMOTD.StaffRanks = { -- Ranks that should up in the staff section of the Panel Count Panel
	"superadmin",
	"owner",
	"admin"
}

MetroMOTD.DonatorRanks = { -- Ranks that should up in the donator section of the Panel Count Panel
	"donator",
	"vip"
}

//Frame Colour
MetroMOTD.BackgroundPanelColour = Color(0,64,80) -- What colour should the background be?

//General
MetroMOTD.TextColour = Color(255,255,255) -- What colour should fonts be?

//Player Panel (Top Left)
MetroMOTD.PlayerPanelColour = Color(0,163,0) -- What colour should the player panel be?
MetroMOTD.PlayerPanelTextColour = Color(255,255,255) -- What colour should the player panel be?

//Panel One - Gamemode and Map information
MetroMOTD.PanelOneColour = Color(45,137,239) -- What colour should the panel be?
MetroMOTD.PanelOneLabelImg = "materials/niandralades/motd/64/64_web.png" -- what should the image be?
MetroMOTD.PanelOneLabelOne = "Gamemode" -- What should the top label be?
MetroMOTD.PanelOneLabelTwo = "Map" -- What text should be on the one below?
MetroMOTD.PanelOneTextTwo = game.GetMap() -- Underneath those label is added information.
timer.Simple(1, function()
MetroMOTD.PanelOneTextOne = GAMEMODE.Name -- File runs before GM stuff has loaded.
end)

//Panel Two - Welcome information. (Top right, spanning across)
MetroMOTD.BigTextColour = Color(255,255,255)
MetroMOTD.SmallTextColour = Color(255,255,255)
MetroMOTD.PanelTwoColour = Color(189, 195, 199)
MetroMOTD.PanelTwoImage = "materials/niandralades/motd/64/64_desktop.png"


//Panel Three - Rules 
MetroMOTD.PanelThreeColour = Color(238,17,17)
MetroMOTD.PanelThreeLabel = "Rules"
MetroMOTD.PanelThree_UsePanel = false -- Should the big red rules part be a panel or a button? If false, then clicking it will open the url below in steam.
MetroMOTD.PanelThree_URLOpen = "http://www.google.co.uk"
MetroMOTD.PanelThreeTextColour = Color(255,255,255)
MetroMOTD.PanelThreeTextMainBodyText = "1. No Mic Spam - You will be muted! \n2. Respect all players. \n3. Do not beg for staff or items. \n4. Report any bugs or glitches. \n5. Do not shit talk pugs" -- \n indicates a new line in lua.
MetroMOTD.PanelThreeImage = "materials/niandralades/motd/256/256_rules.png"

//Panel Four - Custom, donate panel and to the right of Rules.
MetroMOTD.PanelFourColor = Color(126,56,120)
MetroMOTD.PanelFourImage = "materials/niandralades/motd/128/128_donate_1.png"
MetroMOTD.PanelFourLabel = "Donate"
MetroMOTD.PanelFourFunc = "http://www.paypal.co.uk"

//Panel Five - Custom, Website panel and to the right of donate panel.
MetroMOTD.PanelFiveColor = Color(211, 84, 0)
MetroMOTD.PanelFiveImage = "materials/niandralades/motd/128/128_user.png"
MetroMOTD.PanelFiveLabel = "Website"
MetroMOTD.PanelFiveFunc = "http://www.garrysmod.com"

//Panel Six - Custom, Content panel underneath donate.
MetroMOTD.PanelSixColor = Color(255,0,151)
MetroMOTD.PanelSixImage = "materials/niandralades/motd/64/64_box.png"
MetroMOTD.PanelSixLabel = "Content"
MetroMOTD.PanelSixFunc = "http://steamcommunity.com/workshop/browse?appid=4000"

//Panel Seven - Custom, Forums panel and to the right of Content
MetroMOTD.PanelSevenColor = Color(96,60,186)
MetroMOTD.PanelSevenImage = "materials/niandralades/motd/64/64_keyboard.png"
MetroMOTD.PanelSevenLabel = "Forums"
MetroMOTD.PanelSevenFunc = "http://facepunch.com/forum.php"

//Panel Eight - Custom
MetroMOTD.PanelEightColor = Color(227,162,26)
MetroMOTD.PanelEightImage = "materials/niandralades/motd/64/64_announcement.png"
MetroMOTD.PanelEightLabel = "Announcements"
MetroMOTD.PanelEightFunc = "http://steamcommunity.com/app/4000/announcements"

//Panel Eight - Close
MetroMOTD.ClosePanelColor = Color(0,171,169)
MetroMOTD.ClosePanelImage = "materials/niandralades/motd/64/64_cancel.png"

if SERVER then
	
	if MetroMOTD.UseFastDL then

	resource.AddFile("materials/niandralades/motd/64/64_desktop.png")
	resource.AddFile("materials/niandralades/motd/256/256_rules.png")
	resource.AddFile("materials/niandralades/motd/128/128_donate_1.png")
	resource.AddFile("materials/niandralades/motd/128/128_user.png")
	resource.AddFile("materials/niandralades/motd/64/64_keyboard.png")
	resource.AddFile("materials/niandralades/motd/64/64_announcement.png")
	resource.AddFile("materials/niandralades/motd/64/64_cancel.png")
	resource.AddFile("materials/niandralades/motd/special/metromotd_user.png")
	resource.AddFile("materials/niandralades/motd/64/64_box.png")
	resource.AddFile("materials/niandralades/motd/64/64_web.png")
	
	resource.AddFile("resource/fonts/bebasneue.ttf")
	
	else
		resource.AddWorkshop("529645523")
	end
end