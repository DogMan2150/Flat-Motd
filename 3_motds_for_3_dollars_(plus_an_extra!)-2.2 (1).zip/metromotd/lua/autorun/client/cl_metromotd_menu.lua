surface.CreateFont( "Bebas50", {
	font = "Bebas Neue", 
	size = 50, 
	weight = 500, 
	blursize = 0, 
	scanlines = 0, 
	antialias = true, 
	underline = false, 
	italic = false, 
	strikeout = false, 
	symbol = false, 
	rotary = false, 
	shadow = false, 
	additive = false, 
	outline = false, 
} )

surface.CreateFont( "Bebas25", {
	font = "Bebas Neue", 
	size = 25, 
	weight = 500, 
	blursize = 0, 
	scanlines = 0, 
	antialias = true, 
	underline = false, 
	italic = false, 
	strikeout = false, 
	symbol = false, 
	rotary = false, 
	shadow = false, 
	additive = false, 
	outline = false, 
} )

surface.CreateFont( "Tahoma25", {
	font = "Tahoma", 
	size = 25, 
	weight = 500, 
	blursize = 0, 
	scanlines = 0, 
	antialias = true, 
	underline = false, 
	italic = false, 
	strikeout = false, 
	symbol = false, 
	rotary = false, 
	shadow = false, 
	additive = false, 
	outline = false, 
} )


surface.CreateFont( "Tahoma20", {
	font = "Tahoma", 
	size = 20, 
	weight = 500, 
	blursize = 0, 
	scanlines = 0, 
	antialias = true, 
	underline = false, 
	italic = false, 
	strikeout = false, 
	symbol = false, 
	rotary = false, 
	shadow = false, 
	additive = false, 
	outline = false, 
} )


net.Receive("MetroMOTD_Open", function()

	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0,0)
	frame:SetTitle("")
	frame:RequestFocus()
	frame:MakePopup()
	frame:ShowCloseButton(false)
	frame.Paint = function()
		draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), MetroMOTD.BackgroundPanelColour)
	end
	frame.Think = function()
		gui.EnableScreenClicker(true)
	end
	
	function MetroMOTD:CloseMenu()
		frame:Remove()
	end
	
	--CLSE
	local MetroMOTD_Panel_Close = vgui.Create("DButton", frame)
	MetroMOTD_Panel_Close:SetSize(frame:GetWide()-20-20-250-300-40, 100)
	MetroMOTD_Panel_Close:SetPos(frame:GetWide()-20-MetroMOTD_Panel_Close:GetWide(), frame:GetTall()-20-MetroMOTD_Panel_Close:GetTall())
	MetroMOTD_Panel_Close:SetText("")
	MetroMOTD_Panel_Close.Paint = function()
		draw.RoundedBox(0, 0, 0, MetroMOTD_Panel_Close:GetWide(), MetroMOTD_Panel_Close:GetTall(), MetroMOTD.ClosePanelColor)
	end
	MetroMOTD_Panel_Close.DoClick = function()
		MetroMOTD:CloseMenu()
		gui.EnableScreenClicker(false)
	end
	
	local MetroMOTD_Panel_Close_Image = vgui.Create("DImage", MetroMOTD_Panel_Close)
	MetroMOTD_Panel_Close_Image:SetImage(MetroMOTD.ClosePanelImage)
	MetroMOTD_Panel_Close_Image:SetSize(64,64)
	MetroMOTD_Panel_Close_Image:SetPos(MetroMOTD_Panel_Close:GetWide()/2-32,MetroMOTD_Panel_Close:GetTall()/2-32)
	
	local MetroMOTD_Panel_Close_Label = vgui.Create("DLabel", MetroMOTD_Panel_Close)
	MetroMOTD_Panel_Close_Label:SetPos(10,10)
	MetroMOTD_Panel_Close_Label:SetText("Close me!")
	MetroMOTD_Panel_Close_Label:SetFont("Tahoma25")
	MetroMOTD_Panel_Close_Label:SetColor(MetroMOTD.PanelThreeTextColour)
	MetroMOTD_Panel_Close_Label:SizeToContents()
	
	
	local MetroMOTD_PlayerCount_Panel = vgui.Create("DPanel", frame)
	MetroMOTD_PlayerCount_Panel:SetPos(20, 20)
	MetroMOTD_PlayerCount_Panel:SetSize(250, frame:GetTall()/2-40+100)
	MetroMOTD_PlayerCount_Panel.Paint = function()
		draw.RoundedBox(0, 0, 0, MetroMOTD_PlayerCount_Panel:GetWide(), MetroMOTD_PlayerCount_Panel:GetTall(), MetroMOTD.PlayerPanelColour)
	end
	
	/////
	local MetroMOTD_PlayerCount_StaffLabel = vgui.Create("DLabel", MetroMOTD_PlayerCount_Panel)
	MetroMOTD_PlayerCount_StaffLabel:SetText("Staff")
	MetroMOTD_PlayerCount_StaffLabel:SetFont("Tahoma25")
	MetroMOTD_PlayerCount_StaffLabel:SetColor(MetroMOTD.PlayerPanelTextColour)
	MetroMOTD_PlayerCount_StaffLabel:SetPos(10,10)
	
	local loop = 0
	for k, v in pairs(player.GetAll()) do
	local MetroMOTD_PlayerCount_StaffImage = vgui.Create("DImage", MetroMOTD_PlayerCount_Panel)
	MetroMOTD_PlayerCount_StaffImage:SetImage("materials/niandralades/motd/special/metromotd_user.png")
	MetroMOTD_PlayerCount_StaffImage:SetSize(32,32)
	if loop <= 6 then
		MetroMOTD_PlayerCount_StaffImage:SetPos(10+loop*40,50)
	elseif loop > 6 and loop <= 12 then
		MetroMOTD_PlayerCount_StaffImage:SetPos(-270+loop*40,100)
	elseif loop > 12 and loop <= 19 then
		MetroMOTD_PlayerCount_StaffImage:SetPos(-550+loop*40,150)
	end
	
	local MetroMOTD_PlayerCount_Staff_InvisPanel = vgui.Create("DPanel", MetroMOTD_PlayerCount_Panel)
	MetroMOTD_PlayerCount_Staff_InvisPanel:SetSize(32,32)
	if loop <= 6 then
		MetroMOTD_PlayerCount_Staff_InvisPanel:SetPos(10+loop*40,50)
	elseif loop > 6 and loop <= 12 then
		MetroMOTD_PlayerCount_Staff_InvisPanel:SetPos(-270+loop*40,100)
	elseif loop > 12 and loop <= 19 then
		MetroMOTD_PlayerCount_Staff_InvisPanel:SetPos(-550+loop*40,150)
	end
	MetroMOTD_PlayerCount_Staff_InvisPanel:SetToolTip(v:Nick())
	MetroMOTD_PlayerCount_Staff_InvisPanel.Paint = function()
		draw.RoundedBox(0, 0, 0, 32,32, Color(255,255,255,0))
	end
		
		loop = loop + 1

	end
	
	local numberofrows = #player.GetAll()/6
	local MetroMOTD_PlayerCount_DonatorLabel = vgui.Create("DLabel", MetroMOTD_PlayerCount_Panel)
	MetroMOTD_PlayerCount_DonatorLabel:SetText("Donators")
	MetroMOTD_PlayerCount_DonatorLabel:SetFont("Tahoma25")
	MetroMOTD_PlayerCount_DonatorLabel:SizeToContents()
	MetroMOTD_PlayerCount_DonatorLabel:SetColor(MetroMOTD.PlayerPanelTextColour)
	MetroMOTD_PlayerCount_DonatorLabel:SetPos(10,10+100+30*numberofrows)
	
	
	-- 167
	-- loop then reduce...
	-- 
	local loopd = 0
	local divideintosix = loopd % 6
	for k, v in pairs(player.GetAll()) do
	local MetroMOTD_PlayerCount_DonatorImage = vgui.Create("DImage", MetroMOTD_PlayerCount_Panel)
	MetroMOTD_PlayerCount_DonatorImage:SetImage("materials/niandralades/motd/special/metromotd_user.png")
	MetroMOTD_PlayerCount_DonatorImage:SetSize(32,32)
	if loopd <=6 then
		MetroMOTD_PlayerCount_DonatorImage:SetPos(10+loopd*40,50+100+30*numberofrows)
	elseif loopd > 6 and loopd <= 12 then
		MetroMOTD_PlayerCount_DonatorImage:SetPos(-270+loopd*40,50+100+30*numberofrows+50)
	elseif loopd > 12 and loopd <= 19 then
		MetroMOTD_PlayerCount_DonatorImage:SetPos(-550+loopd*40,50+100+30*numberofrows+50+50)
	end -- 76561198004684789
	MetroMOTD_PlayerCount_DonatorImage:SetToolTip("asd")
	
	local MetroMOTD_PlayerCount_Donator_InvisPanel = vgui.Create("DPanel", MetroMOTD_PlayerCount_Panel)
	MetroMOTD_PlayerCount_Donator_InvisPanel:SetSize(32,32)
	if loopd <=6 then
		MetroMOTD_PlayerCount_Donator_InvisPanel:SetPos(10+loopd*40,50+100+30*numberofrows)
	elseif loopd > 6 and loopd <= 12 then
		MetroMOTD_PlayerCount_Donator_InvisPanel:SetPos(-270+loopd*40,50+100+30*numberofrows+50)
	elseif loopd > 12 and loopd <= 19 then
		MetroMOTD_PlayerCount_Donator_InvisPanel:SetPos(-550+loopd*40,50+100+30*numberofrows+50+50)
	end
	MetroMOTD_PlayerCount_Donator_InvisPanel:SetToolTip(v:Nick())
	MetroMOTD_PlayerCount_Donator_InvisPanel.Paint = function()
		draw.RoundedBox(0, 0, 0, 32,32, Color(255,255,255,0))
	end
	
	loopd = loopd + 1
	end
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	--GAMEMODE AND MAP NAME
	local gamemode_maths = frame:GetTall()-MetroMOTD_PlayerCount_Panel:GetTall()-60
	local MetroMOTD_Panel_One = vgui.Create("DPanel", frame)
	MetroMOTD_Panel_One:SetPos(20, 20+MetroMOTD_PlayerCount_Panel:GetTall()+20)
	MetroMOTD_Panel_One:SetSize(MetroMOTD_PlayerCount_Panel:GetWide(),gamemode_maths)
	MetroMOTD_Panel_One.Paint = function()
		draw.RoundedBox(0, 0, 0, MetroMOTD_Panel_One:GetWide(), MetroMOTD_Panel_One:GetTall(), MetroMOTD.PanelOneColour)
	end
	
	local MetroMOTD_Panel_One_Label = vgui.Create("DLabel", MetroMOTD_Panel_One)
	MetroMOTD_Panel_One_Label:SetText(MetroMOTD.PanelOneLabelOne)
	MetroMOTD_Panel_One_Label:SetFont("Tahoma25")
	MetroMOTD_Panel_One_Label:SizeToContents()
	MetroMOTD_Panel_One_Label:SetColor(MetroMOTD.TextColour)
	MetroMOTD_Panel_One_Label:SetPos(10,10)
	
	local MetroMOTD_Panel_One_Label_2 = vgui.Create("DLabel", MetroMOTD_Panel_One)
	MetroMOTD_Panel_One_Label_2:SetText(MetroMOTD.PanelOneLabelTwo)
	MetroMOTD_Panel_One_Label_2:SetFont("Tahoma25")
	MetroMOTD_Panel_One_Label_2:SizeToContents()
	MetroMOTD_Panel_One_Label_2:SetColor(MetroMOTD.TextColour)
	MetroMOTD_Panel_One_Label_2:SetPos(10,10+100)
	
	local MetroMOTD_Panel_One_Text = vgui.Create("DLabel", MetroMOTD_Panel_One)
	MetroMOTD_Panel_One_Text:SetText(MetroMOTD.PanelOneTextOne)
	MetroMOTD_Panel_One_Text:SetFont("Tahoma20")
	MetroMOTD_Panel_One_Text:SizeToContents()
	MetroMOTD_Panel_One_Text:SetColor(MetroMOTD.TextColour)
	MetroMOTD_Panel_One_Text:SetPos(10,10+30)
	
	
	local MetroMOTD_Panel_One_Label_2 = vgui.Create("DLabel", MetroMOTD_Panel_One)
	MetroMOTD_Panel_One_Label_2:SetText(MetroMOTD.PanelOneLabelTwo)
	MetroMOTD_Panel_One_Label_2:SetFont("Tahoma25")
	MetroMOTD_Panel_One_Label_2:SizeToContents()
	MetroMOTD_Panel_One_Label_2:SetColor(MetroMOTD.TextColour)
	MetroMOTD_Panel_One_Label_2:SetPos(10,10+100)
	
	local MetroMOTD_Panel_One_Text = vgui.Create("DLabel", MetroMOTD_Panel_One)
	MetroMOTD_Panel_One_Text:SetText(MetroMOTD.PanelOneTextTwo)
	MetroMOTD_Panel_One_Text:SetFont("Tahoma20")
	MetroMOTD_Panel_One_Text:SizeToContents()
	MetroMOTD_Panel_One_Text:SetColor(MetroMOTD.TextColour)
	MetroMOTD_Panel_One_Text:SetPos(10,10+130)
	
	local MetroMOTD_Panel_One_Image = vgui.Create("DImage", MetroMOTD_Panel_One)
	MetroMOTD_Panel_One_Image:SetImage(MetroMOTD.PanelOneLabelImg)
	MetroMOTD_Panel_One_Image:SetSize(64,64)
	MetroMOTD_Panel_One_Image:SetPos(MetroMOTD_Panel_One:GetWide()-64-10,MetroMOTD_Panel_One:GetTall()-64-10)
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	--HOST NAME AND PLAYER
	local MetroMOTD_Panel_Two = vgui.Create("DPanel", frame)
	MetroMOTD_Panel_Two:SetPos(20+MetroMOTD_Panel_One:GetWide()+20, 20)
	MetroMOTD_Panel_Two:SetSize(frame:GetWide()-MetroMOTD_Panel_One:GetWide()-60, 64+20+20)
	MetroMOTD_Panel_Two.Paint = function()
		draw.RoundedBox(0, 0, 0, MetroMOTD_Panel_Two:GetWide(), MetroMOTD_Panel_Two:GetWide(), MetroMOTD.PanelTwoColour)
	end

	timer.Simple(0.1, function()
	local MetroMOTD_Panel_BigText = vgui.Create("DLabel", MetroMOTD_Panel_Two)
	MetroMOTD_Panel_BigText:SetText(GetHostName())
	MetroMOTD_Panel_BigText:SetFont("Bebas50")
	MetroMOTD_Panel_BigText:SetPos(5,0)
	MetroMOTD_Panel_BigText:SizeToContents()
	MetroMOTD_Panel_BigText:SetColor(MetroMOTD.BigTextColour)
	
	local MetroMOTD_Panel_Two_Image = vgui.Create("DImage", MetroMOTD_Panel_Two)
	MetroMOTD_Panel_Two_Image:SetImage(MetroMOTD.PanelTwoImage)
	MetroMOTD_Panel_Two_Image:SetSize(64,64)
	MetroMOTD_Panel_Two_Image:SetPos(MetroMOTD_Panel_Two:GetWide()-64-20,20)
	
	
	local MetroMOTD_Panel_SmallText = vgui.Create("DLabel", MetroMOTD_Panel_Two)
	MetroMOTD_Panel_SmallText:SetText("Welcome "..LocalPlayer():Nick()..", to our server!")
	MetroMOTD_Panel_SmallText:SetFont("Bebas25")
	MetroMOTD_Panel_SmallText:SetPos(5,40)
	MetroMOTD_Panel_SmallText:SizeToContents()
	MetroMOTD_Panel_SmallText:SetColor(MetroMOTD.SmallTextColour)
	
	end)
	
	///////////////////////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////////////////////
	--RULES PANEL
	
	if MetroMOTD.PanelThree_UsePanel then
		local MetroMOTD_Panel_Three = vgui.Create("DPanel", frame)
		MetroMOTD_Panel_Three:SetPos(20+MetroMOTD_Panel_One:GetWide()+20, 20+MetroMOTD_Panel_Two:GetTall()+20)
		MetroMOTD_Panel_Three:SetSize(300, frame:GetTall()-60-MetroMOTD_Panel_Two:GetTall())
		MetroMOTD_Panel_Three.Paint = function()
			draw.RoundedBox(0, 0, 0, MetroMOTD_Panel_Three:GetWide(), MetroMOTD_Panel_Three:GetTall(), MetroMOTD.PanelThreeColour)
		end
		
		local MetroMOTD_Panel_Three_MainBody = vgui.Create("DLabel", MetroMOTD_Panel_Three)
		MetroMOTD_Panel_Three_MainBody:SetPos(10,50)
		MetroMOTD_Panel_Three_MainBody:SetText(MetroMOTD.PanelThreeTextMainBodyText)
		MetroMOTD_Panel_Three_MainBody:SetFont("Tahoma20")
		MetroMOTD_Panel_Three_MainBody:SetColor(MetroMOTD.PanelThreeTextColour)
		MetroMOTD_Panel_Three_MainBody:SizeToContents()
		
		local MetroMOTD_Panel_Three_Label = vgui.Create("DLabel", MetroMOTD_Panel_Three)
		MetroMOTD_Panel_Three_Label:SetPos(10,10)
		MetroMOTD_Panel_Three_Label:SetText(MetroMOTD.PanelThreeLabel)
		MetroMOTD_Panel_Three_Label:SetFont("Tahoma25")
		MetroMOTD_Panel_Three_Label:SetColor(MetroMOTD.PanelThreeTextColour)
	
		local MetroMOTD_Panel_Three_Image = vgui.Create("DImage", MetroMOTD_Panel_Three)
		MetroMOTD_Panel_Three_Image:SetImage(MetroMOTD.PanelThreeImage)
		MetroMOTD_Panel_Three_Image:SetSize(256,256)
		MetroMOTD_Panel_Three_Image:SetPos(MetroMOTD_Panel_Three:GetWide()/2-128,MetroMOTD_Panel_Three:GetTall()-256-5)
	else
		local MetroMOTD_Panel_Three = vgui.Create("DButton", frame)
		MetroMOTD_Panel_Three:SetText("")
		MetroMOTD_Panel_Three:SetPos(20+MetroMOTD_Panel_One:GetWide()+20, 20+MetroMOTD_Panel_Two:GetTall()+20)
		MetroMOTD_Panel_Three:SetSize(300, frame:GetTall()-60-MetroMOTD_Panel_Two:GetTall())
		MetroMOTD_Panel_Three.Paint = function()
			draw.RoundedBox(0, 0, 0, MetroMOTD_Panel_Three:GetWide(), MetroMOTD_Panel_Three:GetTall(), MetroMOTD.PanelThreeColour)
		end
		MetroMOTD_Panel_Three.DoClick = function()
			gui.OpenURL(MetroMOTD.PanelThree_URLOpen)
		end
		
		local MetroMOTD_Panel_Three_Label = vgui.Create("DLabel", MetroMOTD_Panel_Three)
		MetroMOTD_Panel_Three_Label:SetPos(10,10)
		MetroMOTD_Panel_Three_Label:SetText(MetroMOTD.PanelThreeLabel)
		MetroMOTD_Panel_Three_Label:SetFont("Tahoma25")
		MetroMOTD_Panel_Three_Label:SetColor(MetroMOTD.PanelThreeTextColour)
	
		local MetroMOTD_Panel_Three_Image = vgui.Create("DImage", MetroMOTD_Panel_Three)
		MetroMOTD_Panel_Three_Image:SetImage(MetroMOTD.PanelThreeImage)
		MetroMOTD_Panel_Three_Image:SetSize(256,256)
		MetroMOTD_Panel_Three_Image:SetPos(MetroMOTD_Panel_Three:GetWide()/2-128,MetroMOTD_Panel_Three:GetTall()-256-5)
	end
	
	

	///////////////////////////////////////////////////////////////////////////////////////////////
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	--DONATE
	local halved = frame:GetWide()-80-300-MetroMOTD_PlayerCount_Panel:GetWide()
	local maths = frame:GetTall()-20-20-MetroMOTD_Panel_Two:GetTall()-MetroMOTD_Panel_Close:GetTall()
	local MetroMOTD_Panel_Four = vgui.Create("DButton", frame)
	MetroMOTD_Panel_Four:SetPos(20+MetroMOTD_PlayerCount_Panel:GetWide()+20+300+20, 20+MetroMOTD_Panel_Two:GetTall()+20)
	MetroMOTD_Panel_Four:SetSize(halved/2-10, maths/2)
	MetroMOTD_Panel_Four:SetText("")
	MetroMOTD_Panel_Four.Paint = function()
		draw.RoundedBox(0, 0, 0, MetroMOTD_Panel_Four:GetWide(), MetroMOTD_Panel_Four:GetTall(), MetroMOTD.PanelFourColor)
	end
	MetroMOTD_Panel_Four.DoClick = function()
		gui.OpenURL(MetroMOTD.PanelFourFunc)
	end
	--
	
	local MetroMOTD_Panel_Four_Label = vgui.Create("DLabel", MetroMOTD_Panel_Four)
	MetroMOTD_Panel_Four_Label:SetPos(10,10)
	MetroMOTD_Panel_Four_Label:SetText(MetroMOTD.PanelFourLabel)
	MetroMOTD_Panel_Four_Label:SetFont("Tahoma25")
	MetroMOTD_Panel_Four_Label:SetColor(MetroMOTD.PanelThreeTextColour)
	MetroMOTD_Panel_Four_Label:SizeToContents()
	
	local MetroMOTD_Panel_Four_Image = vgui.Create("DImage", MetroMOTD_Panel_Four)
	MetroMOTD_Panel_Four_Image:SetImage(MetroMOTD.PanelFourImage)
	MetroMOTD_Panel_Four_Image:SetSize(128,128)
	MetroMOTD_Panel_Four_Image:SetPos(MetroMOTD_Panel_Four:GetWide()/2-64,MetroMOTD_Panel_Four:GetTall()/2-64)
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	--WEBSITE 
	local MetroMOTD_Panel_Five = vgui.Create("DButton", frame)
	MetroMOTD_Panel_Five:SetSize(halved/2-10, maths/2)
	MetroMOTD_Panel_Five:SetPos(frame:GetWide()-20-MetroMOTD_Panel_Five:GetWide(), 20+MetroMOTD_Panel_Two:GetTall()+20)
	MetroMOTD_Panel_Five.Paint = function()
		draw.RoundedBox(0, 0, 0, MetroMOTD_Panel_Five:GetWide(), MetroMOTD_Panel_Five:GetTall(), MetroMOTD.PanelFiveColor)
	end
	MetroMOTD_Panel_Five.DoClick = function()
		gui.OpenURL(MetroMOTD.PanelFiveFunc)
	end
	
	local MetroMOTD_Panel_Five_Label = vgui.Create("DLabel", MetroMOTD_Panel_Five)
	MetroMOTD_Panel_Five_Label:SetPos(10,10)
	MetroMOTD_Panel_Five_Label:SetText(MetroMOTD.PanelFiveLabel)
	MetroMOTD_Panel_Five_Label:SetFont("Tahoma25")
	MetroMOTD_Panel_Five_Label:SetColor(MetroMOTD.PanelThreeTextColour)
	MetroMOTD_Panel_Five_Label:SizeToContents()
	
	local MetroMOTD_Panel_Five_Image = vgui.Create("DImage", MetroMOTD_Panel_Five)
	MetroMOTD_Panel_Five_Image:SetImage(MetroMOTD.PanelFiveImage)
	MetroMOTD_Panel_Five_Image:SetSize(128,128)
	MetroMOTD_Panel_Five_Image:SetPos(MetroMOTD_Panel_Five:GetWide()/2-64,MetroMOTD_Panel_Five:GetTall()/2-64)
	///////////////////////////////////////////////////////////////////////////////////////////////
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	--Content/Download
	local split = 60+MetroMOTD_Panel_One:GetWide()+300
	local tall = frame:GetTall()-100-MetroMOTD_Panel_Close:GetTall()-MetroMOTD_Panel_Two:GetTall()-MetroMOTD_Panel_Five:GetTall()
	local three = (frame:GetWide()-split)/3-20
	local MetroMOTD_Panel_Six = vgui.Create("DButton", frame)
	MetroMOTD_Panel_Six:SetPos(split, 20+MetroMOTD_Panel_Two:GetTall()+20+MetroMOTD_Panel_Five:GetTall()+20)
	MetroMOTD_Panel_Six:SetSize(three, tall)
	MetroMOTD_Panel_Six:SetText("")
	MetroMOTD_Panel_Six.Paint = function()
		draw.RoundedBox(0, 0, 0, MetroMOTD_Panel_Six:GetWide(), MetroMOTD_Panel_Six:GetTall(), MetroMOTD.PanelSixColor)
	end
	MetroMOTD_Panel_Six.DoClick = function()
		gui.OpenURL(MetroMOTD.PanelSixFunc)
	end
	
	local MetroMOTD_Panel_Six_Label = vgui.Create("DLabel", MetroMOTD_Panel_Six)
	MetroMOTD_Panel_Six_Label:SetPos(10,10)
	MetroMOTD_Panel_Six_Label:SetText(MetroMOTD.PanelSixLabel)
	MetroMOTD_Panel_Six_Label:SetFont("Tahoma25")
	MetroMOTD_Panel_Six_Label:SetColor(MetroMOTD.PanelThreeTextColour)
	MetroMOTD_Panel_Six_Label:SizeToContents()
	
	local MetroMOTD_Panel_Six_Image = vgui.Create("DImage", MetroMOTD_Panel_Six)
	MetroMOTD_Panel_Six_Image:SetImage(MetroMOTD.PanelSixImage)
	MetroMOTD_Panel_Six_Image:SetSize(64,64)
	MetroMOTD_Panel_Six_Image:SetPos(MetroMOTD_Panel_Six:GetWide()-64-10,MetroMOTD_Panel_Six:GetTall()-64-10)
	
	local MetroMOTD_Panel_Seven = vgui.Create("DButton", frame)
	MetroMOTD_Panel_Seven:SetPos(split+three+20, 20+MetroMOTD_Panel_Two:GetTall()+20+MetroMOTD_Panel_Five:GetTall()+20)
	MetroMOTD_Panel_Seven:SetSize(three, tall)
	MetroMOTD_Panel_Seven:SetText("")
	MetroMOTD_Panel_Seven.Paint = function()
		draw.RoundedBox(0, 0, 0, MetroMOTD_Panel_Seven:GetWide(), MetroMOTD_Panel_Seven:GetTall(), MetroMOTD.PanelSevenColor)
	end
	MetroMOTD_Panel_Seven.DoClick = function()
		gui.OpenURL(MetroMOTD.PanelSevenFunc)
	end
	
	local MetroMOTD_Panel_Seven_Label = vgui.Create("DLabel", MetroMOTD_Panel_Seven)
	MetroMOTD_Panel_Seven_Label:SetPos(10,10)
	MetroMOTD_Panel_Seven_Label:SetText(MetroMOTD.PanelSevenLabel)
	MetroMOTD_Panel_Seven_Label:SetFont("Tahoma25")
	MetroMOTD_Panel_Seven_Label:SetColor(MetroMOTD.PanelThreeTextColour)
	MetroMOTD_Panel_Seven_Label:SizeToContents()
	
	local MetroMOTD_Panel_Seven_Image = vgui.Create("DImage", MetroMOTD_Panel_Seven)
	MetroMOTD_Panel_Seven_Image:SetImage(MetroMOTD.PanelSevenImage)
	MetroMOTD_Panel_Seven_Image:SetSize(64,64)
	MetroMOTD_Panel_Seven_Image:SetPos(MetroMOTD_Panel_Seven:GetWide()-64-10,MetroMOTD_Panel_Seven:GetTall()-64-10)
	
	
	///
	--Announcements
	local MetroMOTD_Panel_Eight = vgui.Create("DButton", frame)
	MetroMOTD_Panel_Eight:SetPos(split+three+three+40, 20+MetroMOTD_Panel_Two:GetTall()+20+MetroMOTD_Panel_Five:GetTall()+20)
	MetroMOTD_Panel_Eight:SetSize(three, tall)
	MetroMOTD_Panel_Eight:SetText("")
	MetroMOTD_Panel_Eight.Paint = function()
		draw.RoundedBox(0, 0, 0, MetroMOTD_Panel_Eight:GetWide(), MetroMOTD_Panel_Eight:GetTall(), MetroMOTD.PanelEightColor)
	end
	MetroMOTD_Panel_Eight.DoClick = function()
		gui.OpenURL(MetroMOTD.PanelEightFunc)
	end
	
	local MetroMOTD_Panel_Eight_Label = vgui.Create("DLabel", MetroMOTD_Panel_Eight)
	MetroMOTD_Panel_Eight_Label:SetPos(10,10)
	MetroMOTD_Panel_Eight_Label:SetText(MetroMOTD.PanelEightLabel)
	MetroMOTD_Panel_Eight_Label:SetFont("Tahoma25")
	MetroMOTD_Panel_Eight_Label:SetColor(MetroMOTD.PanelThreeTextColour)
	MetroMOTD_Panel_Eight_Label:SizeToContents()
	
	local MetroMOTD_Panel_Eight_Image = vgui.Create("DImage", MetroMOTD_Panel_Eight)
	MetroMOTD_Panel_Eight_Image:SetImage(MetroMOTD.PanelEightImage)
	MetroMOTD_Panel_Eight_Image:SetSize(64,64)
	MetroMOTD_Panel_Eight_Image:SetPos(MetroMOTD_Panel_Eight:GetWide()-64-10,MetroMOTD_Panel_Eight:GetTall()-64-10)
	
	
end)

