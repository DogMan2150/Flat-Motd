function GetAdminPlayers()
	local playertable = {}
		for k, v in pairs(player.GetAll()) do
			if table.HasValue(MetroMOTD.StaffRanks, v:GetUserGroup()) then
				table.insert(playertable, v)
			end
		end
	
	return playertable	
end

function GetDonatorPlayers()
	local playertable = {}
		for k, v in pairs(player.GetAll()) do
			if table.HasValue(MetroMOTD.DonatorRanks, v:GetUserGroup()) then
				table.insert(playertable, v)
			end
		end
	
	return playertable	
end
