 util.AddNetworkString( "MetroMOTD_Open" )
 
hook.Add("PlayerSay", "MetroMOTD_Open", function(ply, text, uselessvariable)
	if (text == MetroMOTD.ChatCommand) then
		net.Start("MetroMOTD_Open")
		net.Send(ply)
	end
end)

hook.Add("PlayerInitialSpawn", "MetroMOTD_Spawn", function(ply)
	if MetroMOTD.ShowOnSpawn then // 76561198040331952
	timer.Create("MetroMOTD_Check", 1, 0, function()
		if ply:IsValid() then
			if not table.HasValue(MetroMOTD.WhitelistedGroups, ply:GetUserGroup()) then
				net.Start("MetroMOTD_Open")
				net.Send(ply)
				timer.Destroy("MetroMOTD_Check")
			else
				timer.Destroy("MetroMOTD_Check")
			end
		end	
	end)
	end
end)

concommand.Add(MetroMOTD.ConsoleCommand, function(ply)
	net.Start("MetroMOTD_Open")
	net.Send(ply)
end)