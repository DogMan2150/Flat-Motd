MinecraftMOTD.ButtonsTable = {}
function AddMinecraftMOTDButtons(name, options)
	
	if not name then 
		name = "Button"
    end

	if not options.func then
		func = error("[MINECRAFT MOTD] Button is missing function/url to open! Please address.")
	end

	MinecraftMOTD.ButtonsTable[name] = {
		func = options.func 
	} 
end

