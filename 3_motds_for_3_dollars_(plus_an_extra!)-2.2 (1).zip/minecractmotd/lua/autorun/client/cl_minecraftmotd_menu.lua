surface.CreateFont( "Minecraft_20", {
	font = "Minecraftia", 
	size = 20,
	weight = 500, 
	blursize = 0, 
	scanlines = 0, 
	antialias = true, 
	underline = false, 
	italic = false, 
	strikeout = false, 
	symbol = false, 
	rotary = false, 
	shadow = false, 
	additive = false, 
	outline = false,
} )

net.Receive("MinecraftMOTD_Open", function(len)
	

	local frame = vgui.Create("DFrame")
	frame:SetSize(MinecraftMOTD.FrameWidth,MinecraftMOTD.FrameHeight)
	frame:Center()
	frame:RequestFocus()
	frame:MakePopup()
	frame.Think = function()
		gui.EnableScreenClicker(true)
	end
	
	local loops = 0
	for i=1,7 do
	local MinecraftMOTD_Grass_Tile = vgui.Create("DImage", frame)
	MinecraftMOTD_Grass_Tile:SetPos(0+loops*128,0)
	MinecraftMOTD_Grass_Tile:SetSize(128,128)
	MinecraftMOTD_Grass_Tile:SetImage("materials/niandralades/motd/special/minecraftmotd_tile_grass.png")
	loops = loops + 1
	end
	
	//Doing this is sort of sloppy, I should really be using one loop for everything but getting the height positioning was a fucking pain.
	// 76561198004684789
	local loops1 = 0
	for i=1, 7 do
	local MinecraftMOTD_Grass_Tile = vgui.Create("DImage", frame)
	MinecraftMOTD_Grass_Tile:SetPos(0+loops1*128,128)
	MinecraftMOTD_Grass_Tile:SetSize(128,128)
	MinecraftMOTD_Grass_Tile:SetImage("materials/niandralades/motd/special/minecraftmotd_tile.png")
	loops1 = loops1 + 1
	end
	
	local loops2 = 0
	for i=1, 7 do
	local MinecraftMOTD_Grass_Tile = vgui.Create("DImage", frame)
	MinecraftMOTD_Grass_Tile:SetPos(0+loops2*128,256)
	MinecraftMOTD_Grass_Tile:SetSize(128,128)
	MinecraftMOTD_Grass_Tile:SetImage("materials/niandralades/motd/special/minecraftmotd_tile.png")
	loops2 = loops2 + 1
	end
	
	local loops3 = 0
	for i=1, 7 do
	local MinecraftMOTD_Grass_Tile = vgui.Create("DImage", frame)
	MinecraftMOTD_Grass_Tile:SetPos(0+loops3*128,384)
	MinecraftMOTD_Grass_Tile:SetSize(128,128)
	MinecraftMOTD_Grass_Tile:SetImage("materials/niandralades/motd/special/minecraftmotd_tile.png")
	loops3 = loops3 + 1
	end
	
	
	local loops4 = 0
	for i=1, 7 do
	local MinecraftMOTD_Grass_Tile = vgui.Create("DImage", frame)
	MinecraftMOTD_Grass_Tile:SetPos(0+loops4*128,512)
	MinecraftMOTD_Grass_Tile:SetSize(128,128)
	MinecraftMOTD_Grass_Tile:SetImage("materials/niandralades/motd/special/minecraftmotd_tile.png")
	loops4 = loops4 + 1
	end
	
	local MinecraftMOTD_Banner = vgui.Create("DImage", frame)
	MinecraftMOTD_Banner:SetPos(MinecraftMOTD.FrameWidth/2-MinecraftMOTD.BannerWidth/2, 50)
	MinecraftMOTD_Banner:SetSize(MinecraftMOTD.BannerWidth,MinecraftMOTD.BannerHeight)
	MinecraftMOTD_Banner:SetImage(MinecraftMOTD.Banner)
	
	local num = 0
	for k, v in pairs(MinecraftMOTD.ButtonsTable) do
	local MinecraftMOTD_Buttons = vgui.Create("DButton", frame)
	MinecraftMOTD_Buttons:SetSize(MinecraftMOTD.ButtonWidth, MinecraftMOTD.ButtonHeight)
	MinecraftMOTD_Buttons:SetPos(MinecraftMOTD.FrameWidth/2-MinecraftMOTD.ButtonWidth/2, 50+MinecraftMOTD.BannerHeight+50+num*MinecraftMOTD.ButtonSpacing)
	MinecraftMOTD_Buttons:SetFont("Minecraft_20")
	MinecraftMOTD_Buttons:SetText(k)
	MinecraftMOTD_Buttons:SetColor(MinecraftMOTD.TextColour)
	MinecraftMOTD_Buttons.Paint = function()
		draw.RoundedBox(0, 0, 0, MinecraftMOTD.ButtonWidth, MinecraftMOTD.ButtonHeight, Color(0,0,0)) -- Black Border
		draw.RoundedBox(0, 3, 3, MinecraftMOTD.ButtonWidth-6, MinecraftMOTD.ButtonHeight-6, Color(111,111,111)) -- Main grey panel
		draw.RoundedBox(0, 3, 3, MinecraftMOTD.ButtonWidth-6, 3, Color(170,170,170)) -- Lighter grey top panel
		draw.RoundedBox(0, 3, 3, 3, MinecraftMOTD.ButtonHeight-6-3, Color(170,170,170)) -- Lighter grey down the side
		draw.RoundedBox(0, 3, MinecraftMOTD.ButtonHeight-6-1, 3, 4, Color(115,115,115)) -- Darker grey down the side
		draw.RoundedBox(0, 6, MinecraftMOTD.ButtonHeight-6-1, MinecraftMOTD.ButtonWidth-3-6, 4, Color(80,80,80)) -- Darker grey scaling across the bottom
	end
	num = num + 1
	MinecraftMOTD_Buttons.DoClick = function()
		if type(v.func) == "string" then	   
			if string.find(v.func, "http:") then
				gui.OpenURL(v.func)
			else
				RunConsoleCommand(v.func)
			end	
		else
			v.func()
		end
	end
	end
	
	local MinecraftMOTD_Buttons_Close = vgui.Create("DButton", frame)
	MinecraftMOTD_Buttons_Close:SetSize(MinecraftMOTD.ButtonWidth, MinecraftMOTD.ButtonHeight)
	MinecraftMOTD_Buttons_Close:SetPos(MinecraftMOTD.FrameWidth/2-MinecraftMOTD.ButtonWidth/2, MinecraftMOTD.FrameHeight-MinecraftMOTD.ButtonHeight-MinecraftMOTD.ButtonHeight)
	MinecraftMOTD_Buttons_Close:SetFont("Minecraft_20")
	MinecraftMOTD_Buttons_Close:SetText("Close me")
	MinecraftMOTD_Buttons_Close:SetColor(MinecraftMOTD.TextColour)
	MinecraftMOTD_Buttons_Close.Paint = function()
		draw.RoundedBox(0, 0, 0, MinecraftMOTD.ButtonWidth, MinecraftMOTD.ButtonHeight, Color(0,0,0)) -- Black Border
		draw.RoundedBox(0, 3, 3, MinecraftMOTD.ButtonWidth-6, MinecraftMOTD.ButtonHeight-6, Color(111,111,111)) -- Main grey panel
		draw.RoundedBox(0, 3, 3, MinecraftMOTD.ButtonWidth-6, 3, Color(170,170,170)) -- Lighter grey top panel
		draw.RoundedBox(0, 3, 3, 3, MinecraftMOTD.ButtonHeight-6-3, Color(170,170,170)) -- Lighter grey down the side
		draw.RoundedBox(0, 3, MinecraftMOTD.ButtonHeight-6-1, 3, 4, Color(115,115,115)) -- Darker grey down the side
		draw.RoundedBox(0, 6, MinecraftMOTD.ButtonHeight-6-1, MinecraftMOTD.ButtonWidth-3-6, 4, Color(80,80,80)) -- Darker grey scaling across the bottom
	end
	MinecraftMOTD_Buttons_Close.DoClick = function()
		MinecraftMOTD:CloseMenu()
	end
	
	//123094837 38473 76561198004684789 
	
	function MinecraftMOTD:CloseMenu()
		frame:Remove()
		gui.EnableScreenClicker(false)
	end
end)