//Main frame
MinecraftMOTD.FrameWidth = 800 -- What width should the frame be?
MinecraftMOTD.FrameHeight = 600 -- What height should the frame be? (You may need to create another loop for the background tile)

//Banner
MinecraftMOTD.Banner = "materials/niandralades/motd/special/minecraftmotd_banner.png" -- What image should be used at the top?
MinecraftMOTD.BannerWidth = 512 -- What width should the image be?
MinecraftMOTD.BannerHeight = 128 -- What height should the image be?

//Buttons
MinecraftMOTD.ButtonWidth = 450 -- How wide should the buttons be?
MinecraftMOTD.ButtonHeight = 40 -- How tall should the buttons be?
MinecraftMOTD.ButtonSpacing = 50 -- How much space should there be between the buttons?

//Text
MinecraftMOTD.TextColour = Color(255,255,255) -- What colour should the text on the buttons be?

--If you're planning on having more than five buttons, you may want/need to modify the overall frame size. Don't worry, everything should remain centered!
AddMinecraftMOTDButtons("Website", 
{
	func = "http://www.garrysmod.com/"
})

AddMinecraftMOTDButtons("Rules", 
{
	func = "http://www.garrysmod.com/"
})

AddMinecraftMOTDButtons("Donate", 
{
	func = "http://www.garrysmod.com/"
})

AddMinecraftMOTDButtons("Steam Group", 
{
	func = "http://www.garrysmod.com/"
})

AddMinecraftMOTDButtons("Content", 
{
	func = "http://www.garrysmod.com/"
})