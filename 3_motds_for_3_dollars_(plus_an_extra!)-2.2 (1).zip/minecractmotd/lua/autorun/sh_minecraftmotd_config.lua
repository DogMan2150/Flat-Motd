MinecraftMOTD = MinecraftMOTD or {}

//Server stuff - See client/cl_fullmotd_config.lua for design stuff!
MinecraftMOTD.ChatCommand = "!motd" -- What command should players enter in chat to re-access the MOTD?
MinecraftMOTD.ConsoleCommand = "minecraftmotd" -- What command should players enter in console to re-access the MOTD?
MinecraftMOTD.WhitelistedGroups = { "superadmin", "owner", "admin" } -- What groups should NOT see the MOTD when they enter the server?
MinecraftMOTD.ShowOnSpawn = true -- Should the menu appear when you first initially spawn?
MinecraftMOTD.UseFastDL = true -- Change to false to download from Workshop instead



if SERVER then

	if MinecraftMOTD.UseFastDL then

	resource.AddFile("materials/niandralades/motd/special/minecraftmotd_banner.png")
	resource.AddFile("materials/niandralades/motd/special/minecraftmotd_tile.png")
	resource.AddFile("materials/niandralades/motd/special/minecraftmotd_tile_grass.png")
	
	resource.AddFile("resource/fonts/Minecraftia.ttf")
	
	else
		resource.AddWorkshop("529645523")
	end	
end