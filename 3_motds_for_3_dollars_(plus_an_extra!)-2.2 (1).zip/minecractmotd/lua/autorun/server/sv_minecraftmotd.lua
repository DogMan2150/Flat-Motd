 util.AddNetworkString( "MinecraftMOTD_Open" )
 
hook.Add("PlayerSay", "MinecraftMOTD_Open", function(ply, text, uselessvariable)
	if (text == MinecraftMOTD.ChatCommand) then
		net.Start("MinecraftMOTD_Open")
		net.Send(ply)
	end
end)

hook.Add("PlayerInitialSpawn", "MinecraftMOTD_Spawn", function(ply)
	if MinecraftMOTD.ShowOnSpawn then
	timer.Create("MinecraftMOTD_Open", 1, 0, function()
		if ply:IsValid() then
			if not table.HasValue(MinecraftMOTD.WhitelistedGroups, ply:GetUserGroup()) then
				net.Start("MinecraftMOTD_Open")
				net.Send(ply)
				timer.Destroy("MinecraftMOTD_Open")
			else
				timer.Destroy("MinecraftMOTD_Open")
			end
		end	
	end)
	end
end)

concommand.Add(MinecraftMOTD.ConsoleCommand, function(ply)
	net.Start("MinecraftMOTD_Open")
	net.Send(ply)
	// 76561198040331952
end)

for k, v in pairs(file.Find("materials/niandralades/motd/*.png", "GAME")) do
	resource.AddFile(v)
end