 util.AddNetworkString( "FlatMOTD_Open" )
 
hook.Add("PlayerSay", "FlatMOTD_Open", function(ply, text, uselessvariable)
	if (text == FlatMOTD.ChatCommand) then
		net.Start("FlatMOTD_Open")
		net.Send(ply)
	end
end)

hook.Add("PlayerInitialSpawn", "FlatMOTD_Spawn", function(ply)
	if FlatMOTD.ShowOnSpawn then
	timer.Create("FlatMOTD_Check", 1, 0, function()
		if ply:IsValid() then // 76561198040331952
			if not table.HasValue(FlatMOTD.WhitelistedGroups, ply:GetUserGroup()) then
				net.Start("FlatMOTD_Open")
				net.Send(ply)
				timer.Destroy("FlatMOTD_Check")
			else
				timer.Destroy("FlatMOTD_Check")
			end
		end	
	end)
	end
end)

concommand.Add(FlatMOTD.ConsoleCommand, function(ply)
	net.Start("FlatMOTD_Open")
	net.Send(ply)
end)