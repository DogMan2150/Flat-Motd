surface.CreateFont("Bebas45", {
	font = "Bebas Neue", 
	size = 45, 
	weight = 500, 
	blursize = 0, 
	scanlines = 0, 
	antialias = true, 
	underline = false, 
	italic = false, 
	strikeout = false, 
	symbol = false, 
	rotary = false, 
	shadow = false, 
	additive = false, 
	outline = false, 
})

local thick = 2

net.Receive("FlatMOTD_Open", function(len)
	
	local frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(),ScrH())
	frame:ShowCloseButton(false)
	frame:SetPos(0,0)
	frame:RequestFocus()
	frame:MakePopup()
	frame:SetTitle("")
	frame.Paint = function()
		draw.RoundedBox(0,0,0,frame:GetWide(),frame:GetTall(),Color(0,0,0,150))
	end
	frame.Think = function()
		gui.EnableScreenClicker(true)
	end
	
	function FlatMOTD:CloseMenu()
		frame:Remove()
		gui.EnableScreenClicker(false)
	end
	
	local html_viewer = vgui.Create("HTML", frame)
	html_viewer:SetPos(128+60,20)
	html_viewer:SetSize(frame:GetWide()-128-60-20, frame:GetTall()-40)
	html_viewer:OpenURL(FlatMOTD.DefaultURL)
	
	local tabs_panel = vgui.Create("DPanel", frame)
	tabs_panel:SetPos(0,0)
	tabs_panel:SetSize(128+20+20,ScrH())
	tabs_panel.Paint = function()
		draw.RoundedBox(0,0,0,tabs_panel:GetWide(),tabs_panel:GetTall(),Color(39,44,48))
		draw.RoundedBox(0,0,20+128+50,tabs_panel:GetWide(),thick,Color(56,61,65,150))
		
		draw.RoundedBox(0,16,14,128+8,2,Color(69,200,220))
		draw.RoundedBox(0,16,14+128+10,128+8,2,Color(69,200,220))
		draw.RoundedBox(0,14,14,2,128+12,Color(69,200,220))
		draw.RoundedBox(0,16+128+8,14,2,128+12,Color(69,200,220))
	end
	
	local num = 0
	for k, v in pairs(FlatMOTD.ButtonsTable) do
	local tabs_buttons = vgui.Create("DButton", tabs_panel)
	tabs_buttons:SetText(v.title)
	tabs_buttons:SetSize(tabs_panel:GetWide(),42)
	tabs_buttons:SetPos(0,20+128+50+thick+num*42)
	tabs_buttons:SetColor(Color(81,81,81))
	tabs_buttons.Paint = function()
		draw.RoundedBox(0,0,0,tabs_buttons:GetWide(),tabs_buttons:GetTall(),Color(33,36,41))
		draw.RoundedBox(0,0,tabs_buttons:GetTall()-thick,tabs_buttons:GetWide(),thick,Color(56,61,65,150))
	end
	tabs_buttons.OnCursorEntered = function()
		tabs_buttons:SetColor(Color(255,255,255))
	end
	tabs_buttons.OnCursorExited = function()
		tabs_buttons:SetColor(Color(81,81,81))
	end
	tabs_buttons.DoClick = function()
		html_viewer:OpenURL(v.func)	
	end
	
	local tabs_image = vgui.Create("DImage", tabs_buttons)
	tabs_image:SetPos(3,4)
	tabs_image:SetSize(32,32)
	tabs_image:SetImage(v.icon)
	
	num =  num + 1
	end
	
	local disconnect_button = vgui.Create("DButton", tabs_panel)
	disconnect_button:SetSize(tabs_panel:GetWide()-20, 25)
	disconnect_button:SetText("Disconnect")
	disconnect_button:SetColor(Color(81,81,81))
	disconnect_button:SetPos(10,tabs_panel:GetTall()-10-25)
	disconnect_button.Paint = function()
		draw.RoundedBox(0,0,0,disconnect_button:GetWide(),disconnect_button:GetTall(),Color(56,61,65))
		draw.RoundedBox(0,2,2,disconnect_button:GetWide()-4,disconnect_button:GetTall()-4,Color(33,36,41))
	end
	disconnect_button.OnCursorEntered = function()
		disconnect_button:SetColor(Color(255,255,255))
	end
	disconnect_button.OnCursorExited = function()
		disconnect_button:SetColor(Color(81,81,81))
	end
	disconnect_button.DoClick = function()
		RunConsoleCommand("disconnect")
	end
	
	local close_button = vgui.Create("DButton", tabs_panel)
	close_button:SetSize(tabs_panel:GetWide()-20, 25)
	close_button:SetText("Close")
	close_button:SetColor(Color(81,81,81))
	close_button:SetPos(10,tabs_panel:GetTall()-10-60)
	close_button.Paint = function()
		draw.RoundedBox(0,0,0,close_button:GetWide(),close_button:GetTall(),Color(56,61,65))
		draw.RoundedBox(0,2,2,close_button:GetWide()-4,close_button:GetTall()-4,Color(33,36,41))
	end
	close_button.OnCursorEntered = function()
		close_button:SetColor(Color(255,255,255))
	end
	close_button.OnCursorExited = function()
		close_button:SetColor(Color(81,81,81))
	end
	close_button.DoClick = function()
		FlatMOTD:CloseMenu()
	end	
	
	local Avatar = vgui.Create("AvatarImage", tabs_panel)
	Avatar:SetSize(128,128)
	Avatar:SetPos(20,20)
	Avatar:SetPlayer(LocalPlayer(), 128)
	
end)