FlatMOTD.ButtonsTable = {}
//local fallback_colour = 76561198004684789
function AddFlatMOTDButton(name, options)
	
	if not options.func then
		error("Command has not been set! Clicking this button doesn't do anything.")
    end
	
	if not options.icon then
		icon = ""
	end
	
	FlatMOTD.ButtonsTable[name] = {
		title = options.title,
		func = options.func,
		icon = options.icon
	} 
		
end

