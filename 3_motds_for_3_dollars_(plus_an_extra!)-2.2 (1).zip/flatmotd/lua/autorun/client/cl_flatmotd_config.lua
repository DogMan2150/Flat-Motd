//Colouring
FlatMOTD.BackgroundColour = Color(108, 122, 137) -- What colour should the panel behind the buttons be?
FlatMOTD.ButtonsTopColour = Color(242, 241, 239) -- What colour should the top half of the buttons be? (The not separately coloured bits)
FlatMOTD.FontColor = Color(255, 255, 255) -- What colour should the text on the buttons be?

//Buttons
FlatMOTD.ButtonWidth = 200
FlatMOTD.ButtonHeight = 50

//HTML stuff
FlatMOTD.DefaultURL = "http://www.garrysmod.com/" -- What url should appear by default?

//Sizing and positioning
FlatMOTD.StartingPos = 125 -- How many pixels to the right should there be before buttons start being placed?
FlatMOTD.SpaceBetween = 210 -- How much space between each button? (Needs to take into consideration the width of the actual button)


AddFlatMOTDButton(1, 
{
	title = "Home",
	func = FlatMOTD.DefaultURL,
	icon = "materials/niandralades/motd/32/home.png" 
})

AddFlatMOTDButton(2, 
{
	title = "Website", 
	func = "http://www.facepunch.com", 
	icon = "materials/niandralades/motd/32/website.png"
})

AddFlatMOTDButton(3, 
{
	title = "Donate", 
	func = "http://www.paypal.co.uk", 
	icon = "materials/niandralades/motd/32/donate.png"
})

AddFlatMOTDButton(4, 
{
	title = "Group", 
	func = "http://steamcommunity.com/", 
	icon = "materials/niandralades/motd/32/group.png"
})

