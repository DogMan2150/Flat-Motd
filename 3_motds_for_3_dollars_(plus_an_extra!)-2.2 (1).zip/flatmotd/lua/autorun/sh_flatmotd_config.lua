FlatMOTD = FlatMOTD or {}

//Server stuff - See client/cl_FlatMOTD_config.lua for design stuff!
FlatMOTD.ChatCommand = "!motd" -- What command should players enter in chat to re-access the MOTD?
FlatMOTD.ConsoleCommand = "flatmotd" -- What command should players enter in console to re-access the MOTD?
FlatMOTD.WhitelistedGroups = { "superadmin", "owner", "admin" } -- What groups should NOT see the MOTD when they enter the server?
FlatMOTD.ShowOnSpawn = true -- Should the menu appear when you first initially spawn?
FlatMOTD.UseFastDL = true -- Change to false to download from Workshop instead

if SERVER then
	
	if FlatMOTD.UseFastDL then

	resource.AddFile("materials/niandralades/motd/64/64_rules.png")
	resource.AddFile("materials/niandralades/motd/64/64_web.png")
	resource.AddFile("materials/niandralades/motd/64/64_donate.png")
	resource.AddFile("materials/niandralades/motd/64/64_users.png")
	resource.AddFile("materials/niandralades/motd/64/64_cancel.png")
	
	resource.AddFile("resource/fonts/bebasneue.ttf")
	
	else
		resource.AddWorkshop("529645523")
	end
end